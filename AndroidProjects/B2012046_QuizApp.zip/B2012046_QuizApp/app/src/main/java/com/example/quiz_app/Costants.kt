package com.example.quiz_app

object Costants {
    fun getQuestions():ArrayList<Question> {
        val questionList=ArrayList<Question>()

        val q1=Question(
            id=1,
            question ="What country does this flag belong to?",
            image=R.drawable.ic_flag_of_argentina,
            option1="Viet Nam",
            option2="Argentina",
            option3="Indian",
            option4="USA",
            correctAnswer = 2
        )
        val q2=Question(
            id=2,
            question ="What country does this flag belong to?",
            image=R.drawable.ic_flag_of_australia,
            option1="Viet Nam",
            option2="Australia",
            option3="Indian",
            option4="USA",
            correctAnswer = 2
        )
        val q3=Question(
            id=3,
            question ="What country does this flag belong to?",
            image=R.drawable.ic_flag_of_argentina,
            option1="Viet Nam",
            option2="Argentina",
            option3="Indian",
            option4="USA",
            correctAnswer = 2
        )
        questionList.add(q1)
        questionList.add(q2)
        questionList.add(q3)
            return questionList
    }
}