package com.example.quiz_app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import com.example.quiz_app.databinding.ActivityQuizApp2Binding

class Quiz_app2 : AppCompatActivity() {
    lateinit var binding: ActivityQuizApp2Binding
    var userName: String? = null
    private var questionList: ArrayList<Question>? = null
    private var currentQuestion: Int = 1
    private var yourAnswer: Int = 1
    private var rightAnswer: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQuizApp2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        userName = intent.getStringExtra("USERNAME")
        questionList = Costants.getQuestions()
        binding.progressBar.max = questionList?.size!!
        setQuestion()
        binding.tvOption1.setOnClickListener { selectAnswer(binding.tvOption1, 1) }
        binding.tvOption2.setOnClickListener { selectAnswer(binding.tvOption2, 2) }
        binding.tvOption3.setOnClickListener { selectAnswer(binding.tvOption3, 3) }
        binding.tvOption4.setOnClickListener { selectAnswer(binding.tvOption4, 4) }
        binding.btnSubmit.setOnClickListener { onSubmit() }
    }

    private fun setQuestion() {
        defaultOptionView()
        val question:Question= questionList!![currentQuestion-1]
        updateProgressBar()
        displayQuestionInfo(question)
    }

    private fun defaultOptionView(){
        val options = arrayListOf(binding.tvOption1, binding.tvOption2, binding.tvOption3, binding.tvOption4)
        for (option in options) {
            option.typeface= Typeface.DEFAULT
            option.setBackgroundResource(R.drawable.tv_border_default)
            option.setTextColor(Color.parseColor("#7a8888"))
        }
    }

    private fun updateProgressBar() {
        // tiến trình
        binding.progressBar.progress = currentQuestion
        binding.tvProgressBar.text = "$currentQuestion/${binding.progressBar.max}"
    }

    private fun displayQuestionInfo(question: Question) {
        binding.tvQuestion.text = question.question
        binding.tvOption1.text = question.option1
        binding.tvOption2.text = question.option2
        binding.tvOption3.text = question.option3
        binding.tvOption4.text = question.option4
        binding.ivImage.setImageResource(question.image)
        if (currentQuestion == questionList!!.size) {
            binding.btnSubmit.text = "FINISH"
        } else {
            binding.btnSubmit.text = "SUBMIT"
        }
    }

    private fun selectAnswer(view: TextView,pick:Int){
        defaultOptionView()
        yourAnswer=pick
        view.setTextColor(Color.parseColor("#7a4444"))
        view.setTypeface(view.typeface, Typeface.BOLD)
        view.setBackgroundResource(R.drawable.tv_border_select)
    }

    private fun onSubmit(){
        if(yourAnswer==0){
            currentQuestion++
            if(currentQuestion<= questionList!!.size){
                setQuestion()
            }
            else{
                val intent=Intent(this, Quiz_app3::class.java)
                intent.putExtra("USERNAME",userName)
                intent.putExtra("SCORE", rightAnswer.toString())
                intent.putExtra("TOTAL", questionList!!.size.toString())
                startActivity(intent)
            }
        }
        else{
            // 1
            val question=questionList?.get(currentQuestion-1)
            if(question!!.correctAnswer!=yourAnswer){
                answerView(yourAnswer,R.drawable.tv_border_wrong)
            } else{
                rightAnswer++
            }
            answerView(question!!.correctAnswer,R.drawable.tv_border_correct)
            if(currentQuestion==questionList!!.size){
                binding.btnSubmit.text="FINISH"
            }else{
                binding.btnSubmit.text="GO TO THE QUESTION"
            }
            yourAnswer=0
        }
    }
    private fun answerView(selected: Int, bg: Int) {
        when(selected){
            1->{binding.tvOption1.setBackgroundResource(bg)}
            2->{binding.tvOption2.setBackgroundResource(bg)}
            3->{binding.tvOption3.setBackgroundResource(bg)}
            4->{binding.tvOption4.setBackgroundResource(bg)}
        }
    }
}