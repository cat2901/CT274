package com.example.quiz_app

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.quiz_app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding:ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        binding.btnStart.setOnClickListener{
            if (binding.etName.text?.isEmpty() == true){
                Toast.makeText(this, "please enter your name", Toast.LENGTH_LONG).show()
            }
            else{
                val intent= Intent(this,Quiz_app2::class.java )
                Log.e("Name Log",binding.etName.text.toString())
                intent.putExtra("USERNAME",binding.etName.text.toString())
                startActivity(intent)
            }
        }


    }
}