package com.example.quiz_app

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.quiz_app.databinding.ActivityQuizApp3Binding

class Quiz_app3 : AppCompatActivity() {
    lateinit var  binding: ActivityQuizApp3Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityQuizApp3Binding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.username.text=intent.getStringExtra("USERNAME")
        intent.getIntExtra()
        val correctAnswer=intent.getStringExtra("SCORE")
        val Total=intent.getStringExtra("TOTAL")
        binding.result.setText("Your score $correctAnswer out of  $Total")

        binding.btnfinish.setOnClickListener{
            Toast.makeText(this,"Thanks",Toast.LENGTH_LONG).show()
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}