package com.example.b2012045_huynhtrungtin_uocmo.models

data class RequestRegisterOrLogin(
    val username: String
)
