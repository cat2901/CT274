package com.example.b2012045_huynhtrungtin_uocmo.models

data class UserResponse(
    val success: Boolean,
    val message: String,
    val idUser: String?
)
