package com.example.thbuoi4;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class List extends AppCompatActivity {
    public void back3Onlick( android.view.View view){
        Intent intent= new Intent(this, MainActivity.class);
        this.startActivity(intent);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listlayout);
    }
}
