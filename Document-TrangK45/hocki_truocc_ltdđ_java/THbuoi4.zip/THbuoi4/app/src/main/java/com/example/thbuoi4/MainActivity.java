package com.example.thbuoi4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    public void DangkyOnclick(android.view.View view){
        Intent intent= new Intent(this, DangKy.class);
        this.startActivity(intent);
    }
    public void ViewOnclick(android.view.View view){
        Intent intent= new Intent(this, View.class);
        this.startActivity(intent);
    }
    public void exitClick(android.view.View view){
        this.finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainlayout);
    }
}