package com.example.thbuoi4;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class View extends AppCompatActivity {
    public void ListOnlick( android.view.View view){
        Intent intent= new Intent(this, List.class);
        this.startActivity(intent);
    }
    public void back2Onlick( android.view.View view){
        Intent intent= new Intent(this, MainActivity.class);
        this.startActivity(intent);
    }
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.viewlayout);
    }
}
